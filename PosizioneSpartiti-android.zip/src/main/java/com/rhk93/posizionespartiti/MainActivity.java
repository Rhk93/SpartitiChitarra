package com.rhk93.posizionespartiti;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * L'app "Spartito Chitarra": mostra l'app web (assets/index.html) a schermo intero.
 * - Il pulsante "Apri" sceglie un PDF o una foto dal telefono.
 * - Un PDF o una foto aperti con "Apri con…" o "Condividi" (es. da WhatsApp) vengono caricati subito.
 * - Lo schermo resta acceso mentre l'app è aperta.
 */
public class MainActivity extends Activity {

    private static final int SCEGLI_FILE = 1;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Intent intentInAttesa;
    private boolean paginaPronta = false;

    @Override
    protected void onCreate(Bundle stato) {
        super.onCreate(stato);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                // i link esterni si aprono nel browser
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // nessuna app per aprire il link
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                paginaPronta = true;
                if (intentInAttesa != null) {
                    Intent i = intentInAttesa;
                    intentInAttesa = null;
                    apriDaIntent(i);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*"});
                try {
                    startActivityForResult(Intent.createChooser(i, "Scegli lo spartito"), SCEGLI_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Nessuna app per scegliere i file", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        if (stato != null) {
            web.restoreState(stato);
            paginaPronta = true;
        } else {
            web.loadUrl("file:///android_asset/index.html");
            intentInAttesa = getIntent();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (paginaPronta) apriDaIntent(intent);
        else intentInAttesa = intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SCEGLI_FILE && fileCallback != null) {
            Uri[] risultato = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                risultato = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(risultato);
            fileCallback = null;
        }
    }

    /** Carica nell'app il PDF o la foto arrivati con "Apri con…" o "Condividi". */
    @SuppressWarnings("deprecation")
    private void apriDaIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) {
            u = i.getData();
        } else if (Intent.ACTION_SEND.equals(i.getAction())) {
            Object extra = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (extra instanceof Uri) u = (Uri) extra;
        }
        if (u == null) return;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            if (in == null) return;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            String tipo = getContentResolver().getType(u);
            if (tipo == null) tipo = "";
            String nome = nomeFile(u).replace("'", "").replace("\\", "");
            web.evaluateJavascript("window.openFromAndroid&&openFromAndroid('" + b64 + "','" + tipo + "','" + nome + "')", null);
        } catch (Exception e) {
            Toast.makeText(this, "Non riesco ad aprire il file", Toast.LENGTH_LONG).show();
        }
        // non riaprire lo stesso file se l'app viene ricreata
        i.setAction(Intent.ACTION_MAIN);
    }

    private String nomeFile(Uri u) {
        String nome = "spartito";
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (col >= 0) nome = c.getString(col);
            }
        } catch (Exception e) {
            // nome non disponibile
        }
        return nome;
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
