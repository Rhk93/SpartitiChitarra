package com.rhk93.posizionespartiti;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * L'app "Spartito Chitarra": mostra l'app web (assets/index.html) a schermo intero.
 * - Il pulsante "Apri" sceglie un PDF o una foto dal telefono.
 * - Un PDF o una foto aperti con "Apri con…" o "Condividi" (es. da WhatsApp) vengono caricati subito.
 * - Lo schermo resta acceso mentre l'app è aperta.
 * - "Esporta PDF": il PDF con i nomi delle note viene salvato in Download e si apre "Condividi".
 * - "Link": scarica PDF e foto da Mega, Google Drive, Dropbox, OneDrive… (anche un link condiviso verso l'app).
 */
public class MainActivity extends Activity {

    private static final int SCEGLI_FILE = 1;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Intent intentInAttesa;
    private boolean paginaPronta = false;

    @Override
    protected void onCreate(Bundle stato) {
        super.onCreate(stato);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        web.addJavascriptInterface(new Ponte(), "AndroidApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("file".equals(u.getScheme())) return false;
                // i link esterni si aprono nel browser
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // nessuna app per aprire il link
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                paginaPronta = true;
                if (intentInAttesa != null) {
                    Intent i = intentInAttesa;
                    intentInAttesa = null;
                    apriDaIntent(i);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*"});
                try {
                    startActivityForResult(Intent.createChooser(i, "Scegli lo spartito"), SCEGLI_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Nessuna app per scegliere i file", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }
        });

        if (stato != null) {
            web.restoreState(stato);
            paginaPronta = true;
        } else {
            web.loadUrl("file:///android_asset/index.html");
            intentInAttesa = getIntent();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (paginaPronta) apriDaIntent(intent);
        else intentInAttesa = intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SCEGLI_FILE && fileCallback != null) {
            Uri[] risultato = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                risultato = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(risultato);
            fileCallback = null;
        }
    }

    /** Carica nell'app il PDF o la foto arrivati con "Apri con…" o "Condividi". */
    @SuppressWarnings("deprecation")
    private void apriDaIntent(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) {
            u = i.getData();
        } else if (Intent.ACTION_SEND.equals(i.getAction())) {
            Object extra = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (extra instanceof Uri) u = (Uri) extra;
            // un link condiviso (es. da Mega o Drive): lo apre l'app web
            String testo = i.getStringExtra(Intent.EXTRA_TEXT);
            if (u == null && testo != null && !testo.isEmpty()) {
                web.evaluateJavascript("window.openLinkFromAndroid&&openLinkFromAndroid(" + org.json.JSONObject.quote(testo) + ")", null);
                i.setAction(Intent.ACTION_MAIN);
                return;
            }
        }
        if (u == null) return;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            if (in == null) return;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            String tipo = getContentResolver().getType(u);
            if (tipo == null) tipo = "";
            String nome = nomeFile(u).replace("'", "").replace("\\", "");
            web.evaluateJavascript("window.openFromAndroid&&openFromAndroid('" + b64 + "','" + tipo + "','" + nome + "')", null);
        } catch (Exception e) {
            Toast.makeText(this, "Non riesco ad aprire il file", Toast.LENGTH_LONG).show();
        }
        // non riaprire lo stesso file se l'app viene ricreata
        i.setAction(Intent.ACTION_MAIN);
    }

    /** Collegamento usato dalla pagina web (window.AndroidApp). */
    public class Ponte {
        @JavascriptInterface
        public void savePdf(final String b64, final String nome) {
            runOnUiThread(() -> {
                salvati.clear();
                if (salvaFile(b64, nome, "application/pdf")) condividi("application/pdf");
            });
        }

        @JavascriptInterface
        public void saveFile(final String b64, final String nome, final String mime) {
            runOnUiThread(() -> salvaFile(b64, nome, mime));
        }

        @JavascriptInterface
        public void shareSaved(final String mime) {
            runOnUiThread(() -> condividi(mime));
        }

        /** Scarica un indirizzo internet (senza i limiti del browser) e passa il risultato alla pagina. */
        @JavascriptInterface
        public void request(final String id, final String metodo, final String indirizzo, final String corpo) {
            new Thread(() -> scarica(id, metodo, indirizzo, corpo)).start();
        }
    }

    private void scarica(String id, String metodo, String indirizzo, String corpo) {
        String js;
        try {
            String url = indirizzo;
            java.net.HttpURLConnection c = null;
            for (int salti = 0; salti < 10; salti++) {
                c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(20000);
                c.setReadTimeout(60000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) SpartitoChitarra");
                boolean post = "POST".equalsIgnoreCase(metodo) && corpo != null;
                if (post) {
                    c.setRequestMethod("POST");
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json");
                    try (OutputStream o = c.getOutputStream()) {
                        o.write(corpo.getBytes("UTF-8"));
                    }
                }
                int st = c.getResponseCode();
                if (st >= 300 && st < 400 && c.getHeaderField("Location") != null) {
                    url = new java.net.URL(new java.net.URL(url), c.getHeaderField("Location")).toString();
                    c.disconnect();
                    if (post) metodo = "GET";
                    continue;
                }
                break;
            }
            int stato = c.getResponseCode();
            InputStream in = stato >= 400 ? c.getErrorStream() : c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (in != null) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    if (out.size() > 120 * 1024 * 1024) throw new Exception("file troppo grande");
                }
                in.close();
            }
            String tipo = c.getContentType() == null ? "" : c.getContentType();
            String nome = "";
            String cd = c.getHeaderField("Content-Disposition");
            if (cd != null) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("filename\\*=(?:UTF-8'')?([^;]+)|filename=\"?([^\";]+)").matcher(cd);
                if (m.find()) {
                    nome = m.group(1) != null ? java.net.URLDecoder.decode(m.group(1).replace("\"", ""), "UTF-8") : m.group(2);
                }
            }
            String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            js = "window._netDone&&_netDone(" + org.json.JSONObject.quote(id) + "," + stato + ",'" + b64 + "',"
                    + org.json.JSONObject.quote(tipo) + "," + org.json.JSONObject.quote(nome) + "," + org.json.JSONObject.quote(url) + ")";
        } catch (Exception e) {
            String msg = e.getMessage() == null ? e.toString() : e.getMessage();
            js = "window._netDone&&_netDone(" + org.json.JSONObject.quote(id) + ",0,null," + org.json.JSONObject.quote(msg) + ",'','')";
        }
        final String fin = js;
        runOnUiThread(() -> web.evaluateJavascript(fin, null));
    }

    private final java.util.ArrayList<Uri> salvati = new java.util.ArrayList<>();

    /** Salva un file (PDF o immagine) nella cartella Download. */
    private boolean salvaFile(String b64, String nome, String mime) {
        try {
            byte[] dati = Base64.decode(b64, Base64.DEFAULT);
            if (nome == null || nome.isEmpty()) nome = "spartito-con-nomi";
            if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, nome);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("salvataggio non riuscito");
                try (OutputStream o = getContentResolver().openOutputStream(uri)) {
                    if (o == null) throw new Exception("salvataggio non riuscito");
                    o.write(dati);
                }
                salvati.add(uri);
                Toast.makeText(this, "Salvato in Download: " + nome, Toast.LENGTH_SHORT).show();
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                File f = new File(dir, nome);
                try (FileOutputStream o = new FileOutputStream(f)) {
                    o.write(dati);
                }
                Toast.makeText(this, "Salvato in: " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
            }
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Non riesco a salvare il file", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    /** Apre il menu "Condividi" con i file appena salvati. */
    private void condividi(String mime) {
        if (salvati.isEmpty()) return;
        try {
            Intent s;
            if (salvati.size() == 1) {
                s = new Intent(Intent.ACTION_SEND);
                s.putExtra(Intent.EXTRA_STREAM, salvati.get(0));
            } else {
                s = new Intent(Intent.ACTION_SEND_MULTIPLE);
                s.putParcelableArrayListExtra(Intent.EXTRA_STREAM, new java.util.ArrayList<>(salvati));
            }
            s.setType(mime == null || mime.isEmpty() ? "*/*" : mime);
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(s, "Condividi"));
        } catch (Exception e) {
            // nessuna app per condividere
        }
        salvati.clear();
    }

    private String nomeFile(Uri u) {
        String nome = "spartito";
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (col >= 0) nome = c.getString(col);
            }
        } catch (Exception e) {
            // nome non disponibile
        }
        return nome;
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
